require('./bootstrap');


//window.Vue = require('vue');

//Vue.component('example')


