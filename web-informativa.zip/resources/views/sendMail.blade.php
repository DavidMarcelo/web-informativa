<!DOCTYPE html>
<html>
<head>
    <title>Send Email Example - XpertPhp</title>
</head>
<body>
    <div>
        {{--<p>{{ $mail_detail['first_name'] }}</p>
        <p>{{ $mail_detail['last_name'] }}</p>
        <p>{{ $mail_detail['address'] }}</p>--}}
        <p>Thank you XD XD</p>
    </div>
</body>
</html>