@section('servicios')
<section id="servicios">
    <center><h1>Nuestros Servicios</h1></center>
    <div class="container">
        <!--1-->
        <div class="row">
            <div class="col-6">
                <div class="row">
                    <div class="mb-3 col-4">
                    </div>
                    <div class="mb-3 col-8">
                        <h5><b>Préstamo personal</b></h5>
                        <p>
                            Otorgamos préstamos desde los $50,000 hasta $300,000.00 que 
                            se adaptan a tus necesidades, con una tasa preferencial para 
                            tu negocio, emergencia o cumplir tus sueños.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-6">
            <div class="row">
                    <div class="mb-3 col-4">
                    </div>
                    <div class="mb-3 col-8">
                        <h5><b>Crédito pyme</b></h5>
                        <p>
                            Enfocado a emprendedores y/o empresarios que desean iniciar su propio 
                            negocio a o capital inmediato para decir creciendo el cual puedes usar 
                            en cualquier momento con la tasa más baja.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!--2-->
        <div class="row">
            <div class="col-6">
                <div class="row">
                    <div class="mb-3 col-4">
                    </div>
                    <div class="mb-3 col-8">
                        <h5><b>Préstamo personal</b></h5>
                        <p>
                            Otorgamos préstamos desde los $50,000 hasta $300,000.00 que 
                            se adaptan a tus necesidades, con una tasa preferencial para 
                            tu negocio, emergencia o cumplir tus sueños.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="row">
                    <div class="mb-3 col-4">
                    </div>
                    <div class="mb-3 col-8">
                        <h5><b>Crédito pyme</b></h5>
                        <p>
                            Enfocado a emprendedores y/o empresarios que desean iniciar su propio 
                            negocio a o capital inmediato para decir creciendo el cual puedes usar 
                            en cualquier momento con la tasa más baja.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!--3-->
        <div class="row">
            <div class="col-6">
                <div class="row">
                    <div class="mb-3 col-4">
                    </div>
                    <div class="mb-3 col-8">
                        <h5><b>Préstamo personal</b></h5>
                        <p>
                            Otorgamos préstamos desde los $50,000 hasta $300,000.00 que 
                            se adaptan a tus necesidades, con una tasa preferencial para 
                            tu negocio, emergencia o cumplir tus sueños.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="row">
                    <div class="mb-3 col-4">
                    </div>
                    <div class="mb-3 col-8">
                        <h5><b>Crédito pyme</b></h5>
                        <p>
                            Enfocado a emprendedores y/o empresarios que desean iniciar su propio 
                            negocio a o capital inmediato para decir creciendo el cual puedes usar 
                            en cualquier momento con la tasa más baja.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!--4-->
        <div class="row">
            <div class="col-6">
                <div class="row">
                    <div class="mb-3 col-4">
                    </div>
                    <div class="mb-3 col-8">
                        <h5><b>Préstamo personal</b></h5>
                        <p>
                            Otorgamos préstamos desde los $50,000 hasta $300,000.00 que 
                            se adaptan a tus necesidades, con una tasa preferencial para 
                            tu negocio, emergencia o cumplir tus sueños.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="row">
                    <div class="mb-3 col-4">
                    </div>
                    <div class="mb-3 col-8">
                        <h5><b>Crédito pyme</b></h5>
                        <p>
                            Enfocado a emprendedores y/o empresarios que desean iniciar su propio 
                            negocio a o capital inmediato para decir creciendo el cual puedes usar 
                            en cualquier momento con la tasa más baja.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <img src="/storage/fondo1.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="col-4">
                <img src="/storage/fondo2.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="col-4">
                <img src="/storage/fondo3.jpg" class="d-block w-100" alt="...">
            </div>
        </div>
    </div>
</section>
@endsection